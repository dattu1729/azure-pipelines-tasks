package com.sc.coding;

import java.util.Objects;

public class LogShorteningUtility {
    private static LogShorteningUtility instance = null;

    public static LogShorteningUtility getInstance(){
        if(!Objects.isNull(instance)){
            instance = new LogShorteningUtility();
        }
        return instance;
    }

    public String shortenTheLogMessage(String pattern, String loggerName){
        return "";
    }
}
