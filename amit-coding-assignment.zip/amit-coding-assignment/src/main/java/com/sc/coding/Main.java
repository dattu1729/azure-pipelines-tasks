package com.sc.coding;

public class Main {
    public static void main(String[] args) {
        System.out.println("Test");

        LogShorteningUtility.getInstance().shortenTheLogMessage("10", "com")
    }
}
