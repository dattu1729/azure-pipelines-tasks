package com.sc.coding;

public class LogShortnerUtilityTest {

    @Test
    public void test1(){
        System.out.println("Test 1");
    }
}
