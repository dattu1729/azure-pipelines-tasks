package com.scb.coding;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
	
	public static String helloWorld() {
		return  "Hello";
	}

	public static void main(String[] args) {
		String pattern = "";
		String loggerName = "";

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the logger name : ");
		loggerName = scan.nextLine();

		System.out.println("Enter the pattern : ");
		pattern = scan.nextLine();

		String[] segments = loggerName.split("\\.");
		System.out.println(segments.length);



		logBackShortener(pattern,loggerName);
	}

	public static boolean isPatternValid(String pattern, int length) {
		try {
			int patternLength = Integer.valueOf(pattern);
			if (patternLength < 0 || length == 0 || length <= patternLength) {
				return false;
			}
		} catch (NumberFormatException n) {
			System.out.println(n.getMessage());
			return false;
		}
		return true;
	}

	public static String logBackShortener(String pattern, String loggerName) {
		if (loggerName != null) {
			if (!isPatternValid(pattern, loggerName.length())) {
				return loggerName;
			}
			int patternLength = Integer.valueOf(pattern);
			String[] segments = loggerName.split("\\.");

			if (segments.length == 1) {
				return loggerName;
			} else if(patternLength == 0) {
				return segments[segments.length-1];
			}
			String temp = "";
			String newloggerName = loggerName;

				for(int i=0 ; i<= segments.length - 2 ; i++) {

					temp= temp+segments[i].charAt(0)+".";
					System.out.println(temp);
				}
				/*while (temp.length() < patternLength) {
					for(int j=segments.length - 2 ; j<=0  ; j--) {
//						if(temp.length() + ) {
//
//						}
					}
				}*/
				newloggerName = temp+segments[segments.length-1];
			System.out.println(newloggerName);

			return newloggerName;
		}
		return "";
	}

}
