package com.scb.coding;

import static org.junit.Assert.*;

import org.junit.Test;

public class MainTest {

	@Test
	public void test() {
		assertEquals("Hello", Main.helloWorld());
	}

	@Test
	public void testIsPatternValidReturnsFalseWhenPatternIsNegative() {
		assertEquals(false, Main.isPatternValid("-1", 10));
	}

	@Test
	public void testIsPatternValidReturnsFalseWhenPatternIsString() {
		assertEquals(false, Main.isPatternValid("abc", 10));
	}

	@Test
	public void testIsPatternValidReturnsFalseWhenPatternIsNull() {
		assertEquals(false, Main.isPatternValid(null, 17));
	}

	@Test
	public void testIsPatternValidReturnsFalseWhenPatternBlank() {
		assertEquals(false, Main.isPatternValid("", 25));
	}

	@Test
	public void testLogBackShortenerReturnsSameLoggerNameWhenPatternValidReturnsFalse() {
		assertEquals("com.scb.teng.MSvc", Main.logBackShortener("", "com.scb.teng.MSvc"));
	}

	@Test
	public void testLogBackShortenerReturnsSameLoggerNameWhenPatternLengthIsGreaterThanLoggerNameLength() {
		assertEquals("com.scb.teng.MSvc", Main.logBackShortener("20", "com.scb.teng.MSvc"));
	}

	@Test
	public void testLogBackShortenerReturnsEmptyWhenLoggerNameIsNull() {
		assertEquals("", Main.logBackShortener("10", null));
	}

	@Test
	public void testLogBackShortenerReturnsLastSegmentWhenPatternIsZero() {
		assertEquals("MSvc", Main.logBackShortener("0", "com.scb.teng.MSvc"));
	}

	@Test
	public void testLogBackShortenerReturnsLastSegmentWhenLoggerNameHasNoDot() {
		assertEquals("computer", Main.logBackShortener("10", "computer"));
	}

	@Test
	public void testLogBackShortenerReturnsInitialOfEachSegmentWhenPatternIs6() {
		assertEquals("c.s.t.MSvc", Main.logBackShortener("6", "com.scb.teng.MSvc"));
		assertEquals("c.s.t.i.MSvc", Main.logBackShortener("6", "com.scb.teng.interview.MSvc"));
		assertEquals("c.s.t.i.h.MSvc", Main.logBackShortener("6", "com.scb.teng.interview.handson.MSvc"));
	}



	@Test
	public void testLogBackShortenerReturnsInitialOfEachSegmentWhenPatternIs14() {
		assertEquals("c.s.teng.MSvc", Main.logBackShortener("14", "com.scb.teng.MSvc"));
		assertEquals("c.s.t.i.MSvc", Main.logBackShortener("14", "com.scb.teng.interview.MSvc"));
		assertEquals("c.s.t.i.h.MSvc", Main.logBackShortener("14", "com.scb.teng.interview.handson.MSvc"));
	}

	@Test
	public void testLogBackShortenerReturnsFullnameWhenPatternIsGreaterThanLoggerNAme() {
		assertEquals("com.scb.teng.MSvc", Main.logBackShortener("36", "com.scb.teng.MSvc"));
		assertEquals("com.scb.teng.interview.MSvc", Main.logBackShortener("36", "com.scb.teng.interview.MSvc"));
		assertEquals("com.scb.teng.interview.handson.MSvc", Main.logBackShortener("36", "com.scb.teng.interview.handson.MSvc"));
	}

	@Test
	public void testLogBackShortenerReturnsFullnameWhenPatternIsNegative() {
		assertEquals("com.scb.teng.MSvc", Main.logBackShortener("-1", "com.scb.teng.MSvc"));
		assertEquals("com.scb.teng.interview.MSvc", Main.logBackShortener("-1", "com.scb.teng.interview.MSvc"));
		assertEquals("com.scb.teng.interview.handson.MSvc", Main.logBackShortener("-1", "com.scb.teng.interview.handson.MSvc"));
	}

}
