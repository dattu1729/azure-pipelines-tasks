package main.java.com.sc.coding;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LogShorteningUtility {
    private static LogShorteningUtility instance = null;

    public static LogShorteningUtility getInstance(){
        if(Objects.isNull(instance)){
            instance = new LogShorteningUtility();
        }
        return instance;
    }

    public String shortenTheLogMessage(String pattern, String loggerName){
        if (pattern.isEmpty() || isString(pattern))
            return loggerName;

        int patternInt = Integer.valueOf(pattern);
        String[] words = loggerName.split("\\.");

        int loggerLength = loggerName.length();

        //handle zero pattern
        if(patternInt < 0)
            return loggerName;
        else if(patternInt == 0)
            return words[words.length-1];
        else if(patternInt>=loggerLength)
            return loggerName;

        if(patternInt<loggerLength){
            int charsToBeRemoved = loggerLength - patternInt;
            StringBuilder sb = new StringBuilder();
            int charRemoved = 0;

            for(int i =0; i<words.length-1; i++) {
                String word = words[i];
                int gap = charsToBeRemoved - charRemoved;
                if(charRemoved>charsToBeRemoved){
                    sb.append(word);
                }else{
                    sb.append(word.charAt(0));
                    charRemoved = charRemoved + word.length()-1;
                }
                sb.append('.');
            }
            sb.append(words[words.length-1]);
            return sb.toString();

        }
        return loggerName;
    }

    private static boolean isString(String text){
        Pattern pattern = Pattern.compile("^[a-zA-Z]+$");
        Matcher matcher = pattern.matcher(text);
        Boolean b = matcher.matches();
        return b;
    }

    public static void main(String[] args) {
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("12_", "com.scb.teng.MSvc");
        System.out.println(output);
    }
}
