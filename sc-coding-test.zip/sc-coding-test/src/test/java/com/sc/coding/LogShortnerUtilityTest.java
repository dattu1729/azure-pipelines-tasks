package test.java.com.sc.coding;

import main.java.com.sc.coding.LogShorteningUtility;
import org.junit.Assert;
import org.junit.Test;

public class LogShortnerUtilityTest {

    @Test
    public void maxLengthZeroTest1(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("0", "com.scb.teng.MSvc");
        Assert.assertEquals("MSvc", output);
    }

    @Test
    public void maxLengthZeroTest2(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("0", "com.scb.teng.interview.ISvc");
        Assert.assertEquals("ISvc", output);
    }

    @Test
    public void negativePatternTest(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("-1", "com.scb.teng.MSvc");
        Assert.assertEquals("com.scb.teng.MSvc", output);
    }

    @Test
    public void blankPatternTest(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("", "com.scb.teng.MSvc");
        Assert.assertEquals("com.scb.teng.MSvc", output);
    }

    @Test
    public void patternAsATest(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("A", "com.scb.teng.MSvc");
        Assert.assertEquals("com.scb.teng.MSvc", output);
    }

    @Test
    public void patternAsAnyStringTest(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("AMIT", "com.scb.teng.MSvc");
        Assert.assertEquals("com.scb.teng.MSvc", output);
    }

    @Test
    public void loggerLengthLessThanThanMaxLength(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("30", "com.scb.teng.MSvc");
        Assert.assertEquals("com.scb.teng.MSvc", output);
    }

    @Test
    public void loggerLengthMuchMoreThanThanMaxLength(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("6", "com.scb.teng.MSvc");
        Assert.assertEquals("c.s.t.MSvc", output);
    }

    @Test
    public void loggerLengthSlightlyMoreThanThanMaxLength(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("16", "com.scb.teng.MSvc");
        Assert.assertEquals("c.scb.teng.MSvc", output);
    }

    @Test
    public void test1(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("16", "com.scb.teng.interview.ISvc");
        Assert.assertEquals("c.s.t.i.ISvc", output);
    }

    @Test
    public void test2(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("36", "com.scb.teng.interview.handson.HSvc");
        Assert.assertEquals("com.scb.teng.interview.handson.HSvc", output);
    }

    @Test
    public void test3(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("36", "com.scb.teng.interview.handson.HSvc");
        Assert.assertEquals("com.scb.teng.interview.handson.HSvc", output);
    }

    @Test
    public void test4(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("26", "com.scb.teng.interview.handson.HSvc");
        Assert.assertEquals("c.s.t.i.handson.HSvc", output);
    }

    @Test
    public void test5(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("-100", "com.scb.teng.interview.handson.HSvc");
        Assert.assertEquals("com.scb.teng.interview.handson.HSvc", output);
    }

    @Test
    public void test6(){
        String output = LogShorteningUtility.getInstance().shortenTheLogMessage("14", "com.scb.teng.interview.handson.HSvc");
        Assert.assertEquals("c.s.t.i.h.HSvc", output);
    }

}
